SELECT *
FROM Orders
WHERE ShipCountry = 'Germany'
ORDER BY OrderDate